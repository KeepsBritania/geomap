<div class="top-banner-marquee">
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
      <div class="banner-items">
        <div class="banner-inner-item">
          <h4>Real Time Water Monitoring System</h4>
        </div>
        <div class="banner-inner-item">
        <h4>Using IoT Sensor & Digital Sanitation Management</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Geo Mapping</h4>
        </div>
        <div class="banner-inner-item">
          <h4>Use cntrl + scroll to zoom the map</h4>
        </div>
      </div>
</div>